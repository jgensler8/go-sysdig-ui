# Metric

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MetricId** | **string** |  | [default to null]
**PropertyName** | **string** |  | [default to null]
**Aggregation** | **string** |  | [default to null]
**GroupAggregation** | **string** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


