# Errors

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Errors** | [**[]ModelError**](Error.md) |  | [optional] [default to null]
**Timestamp** | **int64** |  | [optional] [default to null]
**Status** | **int32** |  | [optional] [default to null]
**Error_** | **string** |  | [optional] [default to null]
**Message** | **string** |  | [optional] [default to null]
**Path** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


