# GridConfiguration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Col** | **int32** |  | [default to null]
**Row** | **int32** |  | [default to null]
**SizeX** | **int32** |  | [default to null]
**SizeY** | **int32** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


